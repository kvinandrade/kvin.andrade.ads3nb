use desafio4::BST;

#[test]
fn test_bst_new_and_empty() {
    let bst = BST::new();
    assert!(bst.is_empty());
}

#[test]
fn test_bst_insert_and_search() {
    let mut bst = BST::new();
    bst.insert(10);
    bst.insert(5);
    bst.insert(15);

    assert!(bst.search(10));
    assert!(bst.search(5));
    assert!(bst.search(15));
    assert!(!bst.search(20));
    assert!(!bst.is_empty());
}